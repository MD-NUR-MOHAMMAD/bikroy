@extends('layouts.main', ['title' => 'Home'])
@section('content')
    <H1>Main Layout is here</H1>
@endsection
