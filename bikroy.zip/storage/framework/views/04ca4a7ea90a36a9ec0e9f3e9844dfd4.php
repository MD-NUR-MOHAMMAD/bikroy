<?php $__env->startSection('content'); ?>
    <H1>Main Layout is here</H1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['title' => 'Home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\NUR\bikroy\resources\views/inc/home.blade.php ENDPATH**/ ?>